export interface Dish {
  name: string;
}

export interface Menu {
  starter: Dish;
  soup: Dish;
  main_meat: Dish;
  main_fish: Dish;
  main_veg: Dish;
  dessert: Dish;
}

export interface Buffet {
  soup: Dish;
  starters: Dish[];
  mains: Dish[];
  vegetarian: Dish[];
  sides: Dish[];
  desserts: Dish[];
}

export interface DayMenu {
  day: string;
  date: string;
  type: 'menu' | 'buffet';
  menu: Menu;
  buffet: Buffet;
}

export type WeekMenu = DayMenu[];

export interface SavedDishes {
  // Menu dishes
  starter: Dish[];
  soup: Dish[];
  main_meat: Dish[];
  main_fish: Dish[];
  main_veg: Dish[];
  dessert: Dish[];
  // Buffet dishes - kept separate to allow for different suggestions/saved items
  buffet_soup: Dish[];
  buffet_starters: Dish[];
  buffet_mains: Dish[];
  buffet_vegetarian: Dish[];
  buffet_sides: Dish[];
  buffet_desserts: Dish[];
}

export interface PlanData {
  weekMenu: WeekMenu;
  savedDishes: SavedDishes;
}

export type SavedPlansCollection = Record<string, PlanData>;
