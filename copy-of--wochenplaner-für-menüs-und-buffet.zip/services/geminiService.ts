
import { GoogleGenAI } from "@google/genai";

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

export async function suggestDish(prompt: string): Promise<string> {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });

    const text = response.text.trim();
    // Clean up potential markdown or quotes
    return text.replace(/["*`]/g, '');
  } catch (error) {
    console.error("Error calling Gemini API:", error);
    return "Fehler bei der Vorschlagerstellung";
  }
}
