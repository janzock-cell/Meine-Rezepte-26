import React, { useState, useRef, useEffect } from 'react';
import SparklesIcon from './icons/SparklesIcon';
import type { Dish } from '../types';

interface EditableFieldProps {
  value: string;
  onSave: (newValue: string) => void;
  onSuggest?: () => void;
  isLoading: boolean;
  dishList: Dish[];
  hideSuggestButton?: boolean;
  isReadOnly?: boolean;
  small?: boolean;
}

const EditableField: React.FC<EditableFieldProps> = ({ value, onSave, onSuggest, isLoading, dishList, hideSuggestButton = false, isReadOnly = false, small = false }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [searchTerm, setSearchTerm] = useState(value);
  const [showAll, setShowAll] = useState(false); // Flag to determine if all suggestions are shown
  const wrapperRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    setSearchTerm(value);
  }, [value]);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (wrapperRef.current && !wrapperRef.current.contains(event.target as Node)) {
        setIsEditing(false);
        setSearchTerm(value); // Reset on close to avoid showing old search term
      }
    }
    if (isEditing) {
      document.addEventListener("mousedown", handleClickOutside);
    }
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [isEditing, wrapperRef, value]);

  useEffect(() => {
    if (isEditing) {
      inputRef.current?.focus();
      inputRef.current?.select();
    }
  }, [isEditing]);

  const handleStartEditing = () => {
    if (isReadOnly) return;
    setSearchTerm(value); // Ensure input starts with current value
    setShowAll(true);    // Show all suggestions initially
    setIsEditing(true);
  };

  const handleSave = (newValue: string) => {
    if (newValue.trim()) {
      onSave(newValue);
    }
    setIsEditing(false);
  };
  
  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      handleSave(searchTerm);
    } else if (e.key === 'Escape') {
      setIsEditing(false);
      setSearchTerm(value);
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchTerm(e.target.value);
    setShowAll(false); // Once the user types, switch to filtering mode
  };

  const filteredDishes = showAll
    ? dishList
    : dishList.filter(dish =>
        dish.name.toLowerCase().includes(searchTerm.toLowerCase())
      );
  
  const readOnlyClasses = isReadOnly ? 'cursor-default' : 'cursor-pointer hover:bg-slate-100';
  const sizeClasses = small ? 'px-2.5 py-1.5 text-sm min-h-[38px]' : 'px-3 py-2 min-h-[42px]';


  return (
    <div className="relative" ref={wrapperRef}>
      <div 
        onClick={handleStartEditing} 
        className={`group flex items-center w-full text-slate-800 bg-slate-50 rounded-md transition-colors ${sizeClasses} ${readOnlyClasses}`}
      >
        <span className="flex-grow break-words" title={value}>{value}</span>
        {!hideSuggestButton && !isReadOnly && (
          <button 
            onClick={(e) => {
                e.stopPropagation();
                onSuggest?.();
            }}
            disabled={isLoading}
            className="ml-2 p-1 rounded-full text-amber-500 hover:bg-amber-100 focus:outline-none focus:ring-2 focus:ring-amber-500 focus:ring-opacity-50 transition-colors opacity-0 group-hover:opacity-100 flex-shrink-0"
            aria-label="Gericht vorschlagen"
          >
            {isLoading ? (
                <svg className="animate-spin h-5 w-5 text-amber-600" xmlns="http://www.w.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
            ) : (
                <SparklesIcon />
            )}
          </button>
        )}
      </div>

      {isEditing && (
        <div className="absolute z-10 w-full mt-1 bg-white border border-slate-300 rounded-lg shadow-xl">
          <div className="p-2 border-b border-slate-200">
            <input
              ref={inputRef}
              type="text"
              value={searchTerm}
              onChange={handleInputChange}
              onKeyDown={handleKeyDown}
              className="w-full px-3 py-2 text-slate-700 bg-white border border-slate-300 rounded-md shadow-inner focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="Suchen oder neu eingeben..."
            />
          </div>
          <ul className="max-h-60 overflow-y-auto">
            {filteredDishes.map((dish, index) => (
              <li key={index}>
                <button
                  onClick={() => handleSave(dish.name)}
                  className="w-full text-left px-4 py-2 text-slate-700 hover:bg-blue-500 hover:text-white transition-colors"
                >
                  {dish.name}
                </button>
              </li>
            ))}
            {searchTerm && !dishList.some(d => d.name.toLowerCase() === searchTerm.toLowerCase()) && (
              <li>
                <button
                  onClick={() => handleSave(searchTerm)}
                  className="w-full text-left px-4 py-2 text-green-700 font-semibold bg-green-50 hover:bg-green-500 hover:text-white transition-colors"
                >
                  Neu erstellen: "{searchTerm}"
                </button>
              </li>
            )}
          </ul>
        </div>
      )}
    </div>
  );
};

export default EditableField;