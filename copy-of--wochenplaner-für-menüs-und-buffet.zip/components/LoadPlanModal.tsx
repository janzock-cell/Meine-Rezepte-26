import React from 'react';
import CloseIcon from './icons/CloseIcon';
import TrashIcon from './icons/TrashIcon';

interface LoadPlanModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLoad: (name: string) => void;
  onDelete: (name: string) => void;
  savedPlans: string[];
}

const LoadPlanModal: React.FC<LoadPlanModalProps> = ({ isOpen, onClose, onLoad, onDelete, savedPlans }) => {
  if (!isOpen) {
    return null;
  }

  return (
    <div 
      className="fixed inset-0 bg-slate-900/50 z-50 flex items-center justify-center backdrop-blur-sm"
      onClick={onClose}
    >
      <div 
        className="bg-white rounded-xl shadow-2xl p-6 w-full max-w-lg m-4 flex flex-col"
        onClick={e => e.stopPropagation()}
      >
        <div className="flex justify-between items-center mb-4 flex-shrink-0">
          <h2 className="text-xl font-bold text-slate-800">Gespeicherte Pläne</h2>
          <button 
            onClick={onClose}
            className="p-1 rounded-full text-slate-500 hover:bg-slate-200"
            aria-label="Schließen"
          >
            <CloseIcon />
          </button>
        </div>
        <div className="flex-grow overflow-y-auto max-h-[60vh]">
          {savedPlans.length === 0 ? (
            <p className="text-slate-500 text-center py-8">
              Es sind noch keine Pläne gespeichert.
            </p>
          ) : (
            <ul className="space-y-2">
              {savedPlans.sort((a,b) => a.localeCompare(b)).map(planName => (
                <li key={planName} className="flex items-center justify-between p-3 bg-slate-100 rounded-lg">
                  <span className="font-medium text-slate-700">{planName}</span>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => onLoad(planName)}
                      className="px-4 py-1.5 text-sm bg-green-600 text-white font-semibold rounded-md hover:bg-green-700"
                    >
                      Laden
                    </button>
                    <button
                      onClick={() => onDelete(planName)}
                      className="p-2 text-slate-500 hover:text-rose-600 hover:bg-rose-100 rounded-full"
                      aria-label={`Plan ${planName} löschen`}
                    >
                      <TrashIcon />
                    </button>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>
    </div>
  );
};

export default LoadPlanModal;
