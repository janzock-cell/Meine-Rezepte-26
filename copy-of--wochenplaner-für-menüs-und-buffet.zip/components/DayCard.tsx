import React, { useState, useEffect, useRef } from 'react';
import type { DayMenu, Menu, SavedDishes, Buffet, Dish } from '../types';
import EditableField from './EditableField';
import PlusIcon from './icons/PlusIcon';
import TrashIcon from './icons/TrashIcon';
import SoupIcon from './icons/SoupIcon';
import StarterIcon from './icons/StarterIcon';
import MainsIcon from './icons/MainsIcon';
import VegIcon from './icons/VegIcon';
import SidesIcon from './icons/SidesIcon';
import DessertIcon from './icons/DessertIcon';

interface DayCardProps {
  dayMenu: DayMenu;
  onUpdateMeal: (day: string, mealType: 'menu' | 'buffet', course: keyof Menu | keyof Buffet, newName: string, index?: number) => void;
  onSuggestDish: (day: string, mealType: 'menu' | 'buffet', course: keyof Menu | keyof Buffet, index?: number) => void;
  loadingStates: Record<string, boolean>;
  savedDishes: SavedDishes;
  onUpdateDate: (day: string, newDate: string) => void;
  onUpdateDayType: (day: string, type: 'menu' | 'buffet') => void;
  onAddBuffetDish: (day: string, course: keyof Buffet) => void;
  onRemoveBuffetDish: (day: string, course: keyof Buffet, index: number) => void;
  isReadOnly?: boolean;
}

const menuCourseLabels: Record<keyof Menu, string> = {
    starter: "Vorspeise",
    soup: "Suppe",
    main_meat: "Hauptgang (Fleisch)",
    main_fish: "Hauptgang (Fisch)",
    main_veg: "Hauptgang (Vegetarisch)",
    dessert: "Dessert",
};
const menuCourseOrder: (keyof Menu)[] = ['starter', 'soup', 'main_meat', 'main_fish', 'main_veg', 'dessert'];

const buffetSectionLabels: Record<keyof Buffet, string> = {
    soup: "Suppe",
    starters: "Vorspeisen",
    mains: "Hauptgerichte",
    vegetarian: "Vegetarisch",
    sides: "Beilagen",
    desserts: "Desserts",
};
const buffetSingularLabels: Record<string, string> = {
    starters: "Vorspeise",
    mains: "Hauptgericht",
    vegetarian: "Gericht",
    sides: "Beilage",
    desserts: "Dessert",
};

const buffetIcons: Record<keyof Buffet, React.ReactNode> = {
    soup: <SoupIcon />,
    starters: <StarterIcon />,
    mains: <MainsIcon />,
    vegetarian: <VegIcon />,
    sides: <SidesIcon />,
    desserts: <DessertIcon />,
};


const DayCard: React.FC<DayCardProps> = ({ dayMenu, onUpdateMeal, onSuggestDish, loadingStates, savedDishes, onUpdateDate, onUpdateDayType, onAddBuffetDish, onRemoveBuffetDish, isReadOnly = false }) => {
  const { day, date, menu, buffet, type } = dayMenu;
  const [isEditingDate, setIsEditingDate] = useState(false);
  const dateInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isEditingDate) {
      dateInputRef.current?.focus();
    }
  }, [isEditingDate]);

  const formatDate = (dateString: string) => {
    if (!dateString || isNaN(new Date(dateString).getTime())) {
        return 'Datum auswählen';
    }
    const dateObj = new Date(dateString);
    const adjustedDate = new Date(dateObj.getTime() + dateObj.getTimezoneOffset() * 60000);
    return adjustedDate.toLocaleDateString('de-DE', {
      day: 'numeric',
      month: 'long',
      year: 'numeric',
    });
  };

  const handleDateChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    onUpdateDate(day, e.target.value);
    setIsEditingDate(false);
  };

  const renderMenu = () => {
    return (
      <>
        {menuCourseOrder.map((courseKey) => (
          <div key={courseKey}>
            <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">{menuCourseLabels[courseKey]}</h4>
            <EditableField
              value={menu[courseKey]?.name || ''}
              onSave={(newValue) => onUpdateMeal(day, 'menu', courseKey, newValue)}
              onSuggest={() => onSuggestDish(day, 'menu', courseKey)}
              isLoading={loadingStates[`${day}-menu-${courseKey}-0`] || false}
              dishList={savedDishes[courseKey]}
              isReadOnly={isReadOnly}
            />
          </div>
        ))}
      </>
    );
  };
  
  const renderBuffetSection = (
    courseKey: keyof Buffet, 
    items: Dish[],
    singularLabel: string
  ) => {
    const savedDishesKey = `buffet_${courseKey}` as keyof SavedDishes;
    const title = buffetSectionLabels[courseKey];
    const icon = buffetIcons[courseKey];

    return (
      <div>
        <div className="flex items-center gap-2 text-slate-500">
          {icon}
          <h4 className="text-sm font-bold uppercase tracking-wider">{title}</h4>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 mt-2">
          {items.map((dish, index) => (
             <div key={index} className="group relative">
                <EditableField
                  value={dish.name}
                  onSave={(newValue) => onUpdateMeal(day, 'buffet', courseKey, newValue, index)}
                  onSuggest={() => onSuggestDish(day, 'buffet', courseKey, index)}
                  isLoading={loadingStates[`${day}-buffet-${courseKey}-${index}`] || false}
                  dishList={savedDishes[savedDishesKey]}
                  isReadOnly={isReadOnly}
                  small
                />
              {!isReadOnly && (
                <button
                  onClick={() => onRemoveBuffetDish(day, courseKey, index)}
                  className="absolute top-1/2 -right-2.5 -translate-y-1/2 p-1.5 text-slate-400 hover:text-rose-600 bg-white hover:bg-rose-100 rounded-full transition-all opacity-0 group-hover:opacity-100 shadow"
                  aria-label={`${singularLabel} entfernen`}
                >
                  <TrashIcon />
                </button>
              )}
            </div>
          ))}
           {!isReadOnly && (
            <button
                onClick={() => onAddBuffetDish(day, courseKey)}
                className="flex items-center justify-center gap-2 text-sm text-slate-500 font-semibold hover:text-blue-600 bg-slate-100/50 hover:bg-blue-100/50 border-2 border-dashed border-slate-300 hover:border-blue-400 rounded-lg transition-colors p-2 h-full min-h-[42px]"
            >
                <PlusIcon />
                <span>{singularLabel}</span>
            </button>
           )}
        </div>
      </div>
    );
  };

  const renderBuffet = () => {
    return (
      <div className="space-y-6">
        <div>
          <div className="flex items-center gap-2 text-slate-500">
            {buffetIcons.soup}
            <h4 className="text-sm font-bold uppercase tracking-wider">{buffetSectionLabels.soup}</h4>
          </div>
          <div className="mt-2">
            <EditableField
              value={(buffet.soup as Dish)?.name || ''}
              onSave={(newValue) => onUpdateMeal(day, 'buffet', 'soup', newValue, 0)}
              onSuggest={() => onSuggestDish(day, 'buffet', 'soup', 0)}
              isLoading={loadingStates[`${day}-buffet-soup-0`] || false}
              dishList={savedDishes['buffet_soup']}
              isReadOnly={isReadOnly}
              small
            />
          </div>
        </div>
        
        {renderBuffetSection('starters', buffet.starters, buffetSingularLabels.starters)}
        
        <div className="px-3 py-2 text-slate-600 bg-slate-100 rounded-md text-sm font-medium border border-slate-200">
            Salat vom Buffet, Brot und Butter
        </div>
        
        {renderBuffetSection('mains', buffet.mains, buffetSingularLabels.mains)}
        {renderBuffetSection('vegetarian', buffet.vegetarian, buffetSingularLabels.vegetarian)}
        {renderBuffetSection('sides', buffet.sides, buffetSingularLabels.sides)}
        {renderBuffetSection('desserts', buffet.desserts, buffetSingularLabels.desserts)}
      </div>
    );
  };
  

  return (
    <div className="w-96 bg-white rounded-xl shadow-lg p-6 transform transition-transform hover:-translate-y-1 flex-shrink-0">
      <div className="flex justify-between items-center border-b-2 border-slate-200 pb-3 mb-4 gap-2">
        <h2 className="text-2xl font-bold text-slate-800 flex-shrink-0">
          {day}
        </h2>
        <div className="relative text-right">
          {isReadOnly ? (
             <div className="px-3 py-1 text-sm text-slate-600 font-medium bg-slate-100 rounded-md">
                {formatDate(date)}
             </div>
          ) : isEditingDate ? (
            <input
              ref={dateInputRef}
              type="date"
              value={date}
              onChange={handleDateChange}
              onBlur={() => setIsEditingDate(false)}
              className="w-full text-sm p-1 border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              aria-label={`Datum für ${day}`}
            />
          ) : (
            <button
              onClick={() => setIsEditingDate(true)}
              className="px-3 py-1 text-sm text-slate-600 font-medium bg-slate-100 rounded-md hover:bg-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500 transition-colors"
              aria-label={`Datum für ${day} ändern`}
            >
              {formatDate(date)}
            </button>
          )}
        </div>
      </div>
      
      {!isReadOnly && (
        <div className="mb-4 p-1 bg-slate-200 rounded-lg flex items-center">
          <button
            onClick={() => onUpdateDayType(day, 'menu')}
            className={`w-1/2 py-1.5 text-sm font-semibold rounded-md transition-colors ${type === 'menu' ? 'bg-white text-slate-800 shadow' : 'text-slate-500 hover:bg-slate-300'}`}
          >
            Abendmenü
          </button>
          <button
            onClick={() => onUpdateDayType(day, 'buffet')}
            className={`w-1/2 py-1.5 text-sm font-semibold rounded-md transition-colors ${type === 'buffet' ? 'bg-white text-slate-800 shadow' : 'text-slate-500 hover:bg-slate-300'}`}
          >
            Buffet
          </button>
        </div>
      )}

      <div className="space-y-6">
        {type === 'menu' && (
          <div>
              <h3 className="text-lg font-semibold text-slate-600 mb-2">Abendmenü</h3>
              <div className="space-y-3 pl-2 border-l-2 border-slate-200">
                  {renderMenu()}
              </div>
          </div>
        )}

        {type === 'buffet' && (
          <div>
            <h3 className="text-lg font-semibold text-slate-600 mb-4">Buffet</h3>
            {renderBuffet()}
          </div>
        )}
      </div>
    </div>
  );
};

export default DayCard;