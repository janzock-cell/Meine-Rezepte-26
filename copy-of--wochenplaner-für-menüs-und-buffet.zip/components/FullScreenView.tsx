import React from 'react';
import type { WeekMenu, SavedDishes } from '../types';
import DayCard from './DayCard';
import CloseIcon from './icons/CloseIcon';

interface FullScreenViewProps {
  weekMenu: WeekMenu;
  onClose: () => void;
}

const emptySavedDishes: SavedDishes = {
  starter: [], soup: [], main_meat: [], main_fish: [], main_veg: [], dessert: [],
  buffet_soup: [], buffet_starters: [], buffet_mains: [], buffet_vegetarian: [], buffet_sides: [], buffet_desserts: []
};


const FullScreenView: React.FC<FullScreenViewProps> = ({ weekMenu, onClose }) => {
  return (
    <div className="fixed inset-0 bg-slate-900/75 z-50 flex flex-col items-center justify-center p-4 backdrop-blur-sm animate-fade-in">
       <button
        onClick={onClose}
        className="absolute top-4 right-4 p-2 rounded-full text-white bg-slate-800/50 hover:bg-slate-700/75 focus:outline-none focus:ring-2 focus:ring-white transition-colors"
        aria-label="Vollbildansicht schließen"
      >
        <CloseIcon />
      </button>

      <div className="w-full h-full flex items-center justify-start overflow-x-auto p-8 gap-6">
        {weekMenu.map(dayMenu => (
          <DayCard
            key={dayMenu.day}
            dayMenu={dayMenu}
            onUpdateMeal={() => {}}
            onSuggestDish={() => {}}
            loadingStates={{}}
            savedDishes={emptySavedDishes}
            onUpdateDate={() => {}}
            onUpdateDayType={() => {}}
            onAddBuffetDish={() => {}}
            onRemoveBuffetDish={() => {}}
            isReadOnly={true}
          />
        ))}
      </div>
      <style>{`
        @keyframes fadeIn {
          from { opacity: 0; }
          to { opacity: 1; }
        }
        .animate-fade-in {
          animation: fadeIn 0.3s ease-out forwards;
        }
      `}</style>
    </div>
  );
};

export default FullScreenView;