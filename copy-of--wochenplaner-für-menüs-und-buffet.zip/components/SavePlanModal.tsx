import React, { useState, useEffect } from 'react';
import CloseIcon from './icons/CloseIcon';

interface SavePlanModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (name: string) => void;
}

const SavePlanModal: React.FC<SavePlanModalProps> = ({ isOpen, onClose, onSave }) => {
  const [planName, setPlanName] = useState('');

  useEffect(() => {
    if (isOpen) {
      setPlanName('');
    }
  }, [isOpen]);

  if (!isOpen) {
    return null;
  }

  const handleSave = () => {
    if (planName.trim()) {
      onSave(planName.trim());
    }
  };
  
  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      handleSave();
    }
  };

  return (
    <div 
      className="fixed inset-0 bg-slate-900/50 z-50 flex items-center justify-center backdrop-blur-sm"
      onClick={onClose}
    >
      <div 
        className="bg-white rounded-xl shadow-2xl p-6 w-full max-w-md m-4"
        onClick={e => e.stopPropagation()}
      >
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-bold text-slate-800">Plan speichern unter</h2>
          <button 
            onClick={onClose}
            className="p-1 rounded-full text-slate-500 hover:bg-slate-200"
            aria-label="Schließen"
          >
            <CloseIcon />
          </button>
        </div>
        <p className="text-slate-600 mb-4">
          Geben Sie einen Namen für Ihren Menüplan ein, um ihn später wiederzufinden.
        </p>
        <input
          type="text"
          value={planName}
          onChange={(e) => setPlanName(e.target.value)}
          onKeyDown={handleKeyDown}
          className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          placeholder="z.B. Grillwoche Juli"
          autoFocus
        />
        <div className="flex justify-end gap-3 mt-6">
          <button
            onClick={onClose}
            className="px-5 py-2 bg-slate-200 text-slate-700 font-semibold rounded-lg hover:bg-slate-300"
          >
            Abbrechen
          </button>
          <button
            onClick={handleSave}
            disabled={!planName.trim()}
            className="px-5 py-2 bg-blue-600 text-white font-semibold rounded-lg hover:bg-blue-700 disabled:bg-blue-300 disabled:cursor-not-allowed"
          >
            Speichern
          </button>
        </div>
      </div>
    </div>
  );
};

export default SavePlanModal;
