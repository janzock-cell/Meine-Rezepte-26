import React from 'react';

const BuffetIcon: React.FC = () => (
<svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
  <path strokeLinecap="round" strokeLinejoin="round" d="M9 6.75V15m6-6v8.25m.503-8.25a4.5 4.5 0 01-4.496-4.5c.305-1.519 1.84-2.25 3.32-1.664C18.92 3.844 19.5 5.212 19.5 6.75" />
  <path strokeLinecap="round" strokeLinejoin="round" d="M4.5 12.75v6A2.25 2.25 0 006.75 21h10.5A2.25 2.25 0 0019.5 18.75v-6" />
</svg>
);

export default BuffetIcon;
