import React from 'react';

const DessertIcon: React.FC = () => (
<svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
  <path strokeLinecap="round" strokeLinejoin="round" d="M21 11.25v8.25a1.5 1.5 0 01-1.5 1.5H4.5a1.5 1.5 0 01-1.5-1.5V11.25m18 0a1.5 1.5 0 00-1.5-1.5H4.5a1.5 1.5 0 00-1.5 1.5m18 0v-7.5a1.5 1.5 0 00-1.5-1.5H4.5a1.5 1.5 0 00-1.5 1.5v7.5m1.5-4.5h15" />
</svg>
);

export default DessertIcon;
