import React from 'react';

const VegIcon: React.FC = () => (
<svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
  <path strokeLinecap="round" strokeLinejoin="round" d="M12 6.75C9.761 6.75 8.25 8.261 8.25 10.5c0 1.296.536 2.458 1.342 3.257 1.083 1.083 2.53 1.905 4.408 1.905s3.325-.822 4.408-1.905c.806-.799 1.342-1.961 1.342-3.257 0-2.239-1.511-3.75-3.75-3.75z" />
  <path strokeLinecap="round" strokeLinejoin="round" d="M6.75 14.25c.668 1.988 2.47 3.375 4.5 3.375h1.5c2.03 0 3.832-1.387 4.5-3.375" />
</svg>
);

export default VegIcon;
