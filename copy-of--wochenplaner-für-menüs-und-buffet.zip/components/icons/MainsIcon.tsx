import React from 'react';

const MainsIcon: React.FC = () => (
<svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
  <path strokeLinecap="round" strokeLinejoin="round" d="M4.75 17h14.5M6 17v-5.223c0-1.427.633-2.754 1.68-3.666 1.046-.912 2.483-1.444 3.99-1.444 1.507 0 2.944.532 3.99 1.444C16.737 8.98 17.37 10.306 17.37 11.777V17" />
  <path strokeLinecap="round" strokeLinejoin="round" d="M12 6.75a2.25 2.25 0 110-4.5 2.25 2.25 0 010 4.5z" />
</svg>
);

export default MainsIcon;
