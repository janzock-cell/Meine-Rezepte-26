import React from 'react';

const SoupIcon: React.FC = () => (
<svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
  <path strokeLinecap="round" strokeLinejoin="round" d="M12 6.75c-2.394 0-4.552.616-6.443 1.68C3.596 9.422 2.25 10.922 2.25 12.75v.062c0 1.828 1.346 3.328 3.193 4.218C7.448 18.14 9.606 18.75 12 18.75c2.394 0 4.552-.616 6.443-1.68C20.404 16.14 21.75 14.64 21.75 12.812v-.062c0-1.828-1.346-3.328-3.193-4.218A19.146 19.146 0 0012 6.75zm3 5.25a.75.75 0 11-1.5 0 .75.75 0 011.5 0zm-4.5.75a.75.75 0 100-1.5.75.75 0 000 1.5zm-3.75-3a.75.75 0 11-1.5 0 .75.75 0 011.5 0z" />
</svg>
);

export default SoupIcon;
