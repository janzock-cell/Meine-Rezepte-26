import React from 'react';

const SidesIcon: React.FC = () => (
<svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
  <path strokeLinecap="round" strokeLinejoin="round" d="M5.25 21a2.25 2.25 0 01-2.25-2.25V12a2.25 2.25 0 012.25-2.25h13.5A2.25 2.25 0 0121 12v6.75a2.25 2.25 0 01-2.25 2.25H5.25z" />
  <path strokeLinecap="round" strokeLinejoin="round" d="M6 18.75c0-1.995 2.686-3.75 6-3.75s6 1.755 6 3.75" />
</svg>
);

export default SidesIcon;
