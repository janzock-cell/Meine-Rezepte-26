import React from 'react';

const FishIcon: React.FC = () => (
<svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
  <path strokeLinecap="round" strokeLinejoin="round" d="M11.25 12.75c0 .747.166 1.455.47 2.097m0 0A3.75 3.75 0 0015 12.75H6.75A3.75 3.75 0 003 16.5v.75c0 1.206.745 2.24 1.808 2.672C6.084 20.34 7.437 21 9 21h6c1.563 0 2.916-.66 3.992-1.728.752-.733 1.241-1.688 1.432-2.738.288-1.583-1.03-2.963-2.432-2.963H11.25zM12 3.75c0 .747.166 1.455.47 2.097m0 0a3.75 3.75 0 003.28 2.09h4.5a3.75 3.75 0 003.75-3.75V6.75A3.75 3.75 0 0019.5 3h-.75c-1.206 0-2.24.745-2.672 1.808C14.916 6.084 13.563 7.5 12 7.5v-3.75z" />
</svg>
);

export default FishIcon;
