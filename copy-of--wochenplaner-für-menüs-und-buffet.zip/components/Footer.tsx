import React from 'react';

interface FooterProps {
  onReset: () => void;
  onSave: () => void;
  onLoad: () => void;
}

const Footer: React.FC<FooterProps> = ({ onReset, onSave, onLoad }) => {
  return (
    <footer className="bg-white w-full mt-auto">
      <div className="max-w-screen-2xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-center items-center gap-4 flex-wrap">
        <button
          onClick={onLoad}
          className="px-6 py-2 bg-green-600 text-white font-semibold rounded-lg shadow-md hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-opacity-75 transition-colors"
        >
          Plan laden
        </button>
        <button
          onClick={onSave}
          className="px-6 py-2 bg-blue-600 text-white font-semibold rounded-lg shadow-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-opacity-75 transition-colors"
        >
          Plan speichern
        </button>
        <button
          onClick={onReset}
          className="px-6 py-2 bg-rose-600 text-white font-semibold rounded-lg shadow-md hover:bg-rose-700 focus:outline-none focus:ring-2 focus:ring-rose-500 focus:ring-opacity-75 transition-colors"
        >
          Woche zurücksetzen
        </button>
      </div>
    </footer>
  );
};

export default Footer;