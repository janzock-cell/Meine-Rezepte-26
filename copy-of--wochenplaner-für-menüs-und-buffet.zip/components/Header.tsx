import React from 'react';
import ExpandIcon from './icons/ExpandIcon';

interface HeaderProps {
  onToggleFullScreen: () => void;
}

const Header: React.FC<HeaderProps> = ({ onToggleFullScreen }) => {
  return (
    <header className="bg-white shadow-sm w-full">
      <div className="max-w-screen-2xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-slate-900 tracking-tight">
            Wochenplaner für Menüs
          </h1>
          <p className="text-slate-500 mt-1">
            Planen Sie Ihre Mahlzeiten für die Woche. Klicken Sie auf ein Gericht, um es zu bearbeiten.
          </p>
        </div>
        <button
          onClick={onToggleFullScreen}
          className="p-2 rounded-full text-slate-500 hover:bg-slate-100 hover:text-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-opacity-75 transition-colors"
          aria-label="Vollbildansicht umschalten"
        >
          <ExpandIcon />
        </button>
      </div>
    </header>
  );
};

export default Header;