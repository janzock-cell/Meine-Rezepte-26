import React, { useState, useCallback, useMemo } from 'react';
import { INITIAL_WEEK_MENU, INITIAL_SAVED_ISHES, DEFAULT_BUFFET_CONTENT } from './constants';
import type { WeekMenu, DayMenu, Menu, Dish, SavedDishes, Buffet, PlanData, SavedPlansCollection } from './types';
import { suggestDish } from './services/geminiService';
import DayCard from './components/DayCard';
import Header from './components/Header';
import Footer from './components/Footer';
import FullScreenView from './components/FullScreenView';
import SavePlanModal from './components/SavePlanModal';
import LoadPlanModal from './components/LoadPlanModal';

const ALL_PLANS_STORAGE_KEY = 'wochenplanerAllPlans';

const getSavedPlans = (): SavedPlansCollection => {
  try {
    const savedData = localStorage.getItem(ALL_PLANS_STORAGE_KEY);
    if (savedData) {
      return JSON.parse(savedData) as SavedPlansCollection;
    }
  } catch (error) {
    console.error("Could not load plans from localStorage", error);
  }
  return {};
};

const App: React.FC = () => {
  const [weekMenu, setWeekMenu] = useState<WeekMenu>(INITIAL_WEEK_MENU);
  const [savedDishes, setSavedDishes] = useState<SavedDishes>(INITIAL_SAVED_ISHES);
  const [loadingStates, setLoadingStates] = useState<Record<string, boolean>>({});
  const [notification, setNotification] = useState<string | null>(null);
  const [isFullScreen, setIsFullScreen] = useState(false);
  const [isSaveModalOpen, setIsSaveModalOpen] = useState(false);
  const [isLoadModalOpen, setIsLoadModalOpen] = useState(false);
  
  // Force a re-render when plans are deleted to update the list in the modal
  const [plansVersion, setPlansVersion] = useState(0); 

  const savedPlans = useMemo(() => getSavedPlans(), [plansVersion]);
  
  const showNotification = (message: string) => {
    setNotification(message);
    setTimeout(() => {
      setNotification(null);
    }, 3000);
  };

  const handleUpdateDate = useCallback((day: string, newDate: string) => {
    setWeekMenu(currentMenu =>
      currentMenu.map(dayMenu =>
        dayMenu.day === day ? { ...dayMenu, date: newDate } : dayMenu
      )
    );
  }, []);

  const handleUpdateDayType = useCallback((day: string, type: 'menu' | 'buffet') => {
    setWeekMenu(currentMenu =>
      currentMenu.map(dayMenu => {
        if (dayMenu.day === day) {
          // If switching to buffet from menu, replace buffet content with defaults
          if (type === 'buffet' && dayMenu.type !== 'buffet') {
            return { ...dayMenu, type, buffet: DEFAULT_BUFFET_CONTENT };
          }
          // Otherwise, just switch the type
          return { ...dayMenu, type };
        }
        return dayMenu;
      })
    );
  }, []);

  const handleUpdateMeal = useCallback((day: string, mealType: 'menu' | 'buffet', course: keyof Menu | keyof Buffet, newName: string, index?: number) => {
    setSavedDishes(currentSaved => {
      const savedDishesKey = mealType === 'buffet'
        ? `buffet_${course}` as keyof SavedDishes
        : course as keyof SavedDishes;
      
      const categoryDishes = currentSaved[savedDishesKey] || [];
      const isNewAndValidDish = newName && !categoryDishes.some(d => d.name.toLowerCase() === newName.toLowerCase());

      if (isNewAndValidDish) {
        const updatedCategory = [...categoryDishes, { name: newName }]
          .sort((a, b) => a.name.localeCompare(b.name));
        return { ...currentSaved, [savedDishesKey]: updatedCategory };
      }
      return currentSaved;
    });

    setWeekMenu(currentMenu =>
      currentMenu.map(dayMenu => {
        if (dayMenu.day === day) {
          if (mealType === 'menu') {
            const updatedMenu = { ...dayMenu.menu, [course]: { name: newName } };
            return { ...dayMenu, menu: updatedMenu };
          }
          if (mealType === 'buffet') {
            const updatedBuffet = { ...dayMenu.buffet };
            const buffetCourse = course as keyof Buffet;
            if (Array.isArray(updatedBuffet[buffetCourse]) && typeof index === 'number') {
              const newArray = [...(updatedBuffet[buffetCourse] as Dish[])];
              newArray[index] = { name: newName };
              (updatedBuffet[buffetCourse] as Dish[]) = newArray;
            } else {
              (updatedBuffet[buffetCourse] as Dish) = { name: newName };
            }
            return { ...dayMenu, buffet: updatedBuffet };
          }
        }
        return dayMenu;
      })
    );
  }, []);
  
  const handleAddBuffetDish = useCallback((day: string, course: keyof Buffet) => {
    setWeekMenu(currentMenu =>
      currentMenu.map(dayMenu => {
        if (dayMenu.day === day) {
          const updatedBuffet = { ...dayMenu.buffet };
          const buffetCourse = course as keyof Buffet;
          if (Array.isArray(updatedBuffet[buffetCourse])) {
            (updatedBuffet[buffetCourse] as Dish[]).push({ name: '' });
          }
          return { ...dayMenu, buffet: updatedBuffet };
        }
        return dayMenu;
      })
    );
  }, []);

  const handleRemoveBuffetDish = useCallback((day: string, course: keyof Buffet, index: number) => {
    setWeekMenu(currentMenu =>
      currentMenu.map(dayMenu => {
        if (dayMenu.day === day) {
          const updatedBuffet = { ...dayMenu.buffet };
          const buffetCourse = course as keyof Buffet;
          if (Array.isArray(updatedBuffet[buffetCourse])) {
            const newArray = (updatedBuffet[buffetCourse] as Dish[]).filter((_, i) => i !== index);
            (updatedBuffet[buffetCourse] as Dish[]) = newArray;
          }
          return { ...dayMenu, buffet: updatedBuffet };
        }
        return dayMenu;
      })
    );
  }, []);

  const courseLabels: Record<string, string> = { /* ... */ };

  const handleSuggestDish = async (day: string, mealType: 'menu' | 'buffet', course: keyof Menu | keyof Buffet, index?: number) => {
    const loadingKey = `${day}-${mealType}-${course}-${index ?? 0}`;
    setLoadingStates(prev => ({ ...prev, [loadingKey]: true }));
    try {
      // ... existing suggestion logic
    } catch (error) {
      console.error("Error fetching suggestion:", error);
    } finally {
      setLoadingStates(prev => ({ ...prev, [loadingKey]: false }));
    }
  };
  
  const handleResetWeek = useCallback(() => {
    setWeekMenu(INITIAL_WEEK_MENU);
    setSavedDishes(INITIAL_SAVED_ISHES);
    showNotification("Wochenplan auf Standard zurückgesetzt.");
  }, []);

  const handleSavePlan = (planName: string) => {
    const currentPlans = getSavedPlans();
    if (currentPlans[planName]) {
      if (!window.confirm(`Ein Plan mit dem Namen "${planName}" existiert bereits. Möchten Sie ihn überschreiben?`)) {
        return;
      }
    }
    const newPlanData: PlanData = { weekMenu, savedDishes };
    const updatedPlans: SavedPlansCollection = { ...currentPlans, [planName]: newPlanData };
    
    try {
        localStorage.setItem(ALL_PLANS_STORAGE_KEY, JSON.stringify(updatedPlans));
        showNotification(`Plan "${planName}" erfolgreich gespeichert!`);
        setIsSaveModalOpen(false);
        setPlansVersion(v => v + 1);
    } catch (error) {
        console.error("Could not save plan to localStorage", error);
        showNotification("Fehler beim Speichern des Plans.");
    }
  };

  const handleLoadPlan = (planName: string) => {
    const plans = getSavedPlans();
    const planToLoad = plans[planName];
    if (planToLoad) {
      setWeekMenu(planToLoad.weekMenu);
      setSavedDishes(planToLoad.savedDishes);
      setIsLoadModalOpen(false);
      showNotification(`Plan "${planName}" erfolgreich geladen!`);
    } else {
      showNotification("Fehler: Plan nicht gefunden.");
    }
  };

  const handleDeletePlan = (planName: string) => {
    if (!window.confirm(`Möchten Sie den Plan "${planName}" wirklich endgültig löschen?`)) {
        return;
    }
    const plans = getSavedPlans();
    delete plans[planName];
    try {
        localStorage.setItem(ALL_PLANS_STORAGE_KEY, JSON.stringify(plans));
        showNotification(`Plan "${planName}" gelöscht.`);
        setPlansVersion(v => v + 1); // Trigger re-read of plans
    } catch (error) {
        console.error("Could not delete plan from localStorage", error);
        showNotification("Fehler beim Löschen des Plans.");
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 flex flex-col">
      {notification && (
        <div className="fixed top-5 left-1/2 bg-slate-800 text-white py-2 px-6 rounded-lg shadow-lg z-50 animate-fade-in-out">
          {notification}
        </div>
      )}
      <Header onToggleFullScreen={() => setIsFullScreen(!isFullScreen)} />
      <main className="flex-grow w-full max-w-screen-2xl mx-auto p-4 md:p-8">
        <div className="flex gap-6 pb-4 overflow-x-auto">
          {weekMenu.map(dayMenu => (
            <DayCard
              key={dayMenu.day}
              dayMenu={dayMenu}
              onUpdateMeal={handleUpdateMeal}
              onSuggestDish={handleSuggestDish}
              loadingStates={loadingStates}
              savedDishes={savedDishes}
              onUpdateDate={handleUpdateDate}
              onUpdateDayType={handleUpdateDayType}
              onAddBuffetDish={handleAddBuffetDish}
              onRemoveBuffetDish={handleRemoveBuffetDish}
            />
          ))}
        </div>
      </main>
      <Footer 
        onReset={handleResetWeek} 
        onSave={() => setIsSaveModalOpen(true)} 
        onLoad={() => setIsLoadModalOpen(true)} 
      />
      {isFullScreen && (
        <FullScreenView 
          weekMenu={weekMenu} 
          onClose={() => setIsFullScreen(false)} 
        />
      )}
      <SavePlanModal
        isOpen={isSaveModalOpen}
        onClose={() => setIsSaveModalOpen(false)}
        onSave={handleSavePlan}
      />
      <LoadPlanModal
        isOpen={isLoadModalOpen}
        onClose={() => setIsLoadModalOpen(false)}
        onLoad={handleLoadPlan}
        onDelete={handleDeletePlan}
        savedPlans={Object.keys(savedPlans)}
      />
    </div>
  );
};

export default App;