import type { WeekMenu, SavedDishes, Dish, Menu, Buffet } from './types';

const getNextWeekDates = (): string[] => {
  const dates: string[] = [];
  const today = new Date();
  for (let i = 0; i < 7; i++) {
    const nextDay = new Date(today);
    nextDay.setDate(today.getDate() + i);
    dates.push(nextDay.toISOString().split('T')[0]);
  }
  return dates;
};

const weekDates = getNextWeekDates();

export const DEFAULT_BUFFET_CONTENT: Buffet = {
    soup: { name: 'Saisonale Cremesuppe' },
    starters: [ { name: 'Auswahl an Blattsalaten mit Dressings' }, { name: 'Brotkorb mit verschiedenen Aufstrichen' }, { name: 'Tomate-Mozzarella mit Basilikum' } ],
    mains: [ { name: 'Medaillons vom Schweinefilet in Champignonrahmsauce' }, { name: 'Pochiertes Lachsfilet auf Dill-Gurken' } ],
    vegetarian: [ { name: 'Kartoffel-Gemüse-Auflauf mit Käse überbacken' } ],
    sides: [ { name: 'Petersilienkartoffeln' }, { name: 'Bunte Gemüseplatte' }, { name: 'Spätzle' } ],
    desserts: [ { name: 'Herrencreme' }, { name: 'Rote Grütze mit Vanillesauce' } ]
};

export const INITIAL_WEEK_MENU: WeekMenu = [
  {
    day: 'Montag',
    date: weekDates[0],
    type: 'menu',
    menu: {
      starter: { name: 'Rinder-Carpaccio mit Rucola und Parmesan' },
      soup: { name: 'Klare Ochsenschwanzsuppe mit Sherry' },
      main_meat: { name: 'Rosa gebratenes Lammkarree mit Kräuterkruste' },
      main_fish: { name: 'Gebratenes Zanderfilet auf Lauchgemüse' },
      main_veg: { name: 'Handgemachte Trüffel-Ravioli in Salbeibutter' },
      dessert: { name: 'Lauwarmes Schokoladentörtchen mit flüssigem Kern' },
    },
    buffet: { 
        soup: { name: 'Tomatencremesuppe mit Basilikum' },
        starters: [ { name: 'Caesar Salad Station' }, { name: 'Griechischer Bauernsalat' }, { name: 'Vitello Tonnato' }, { name: 'Antipasti-Variation' } ],
        mains: [ { name: 'Rindergulasch "Esterhazy"' }, { name: 'Gebratenes Lachsfilet auf Blattspinat' }, { name: 'Hähnchenbrust in Champignonrahmsauce' }, { name: 'Schweinekrustenbraten' } ],
        vegetarian: [ { name: 'Gemüselasagne' }, { name: 'Käsespätzle mit Röstzwiebeln' } ],
        sides: [ { name: 'Rosmarinkartoffeln' }, { name: 'Basmatireis' }, { name: 'Butterspätzle' }, { name: 'Marktgemüse der Saison' } ],
        desserts: [ { name: 'Mousse au Chocolat' }, { name: 'Panna Cotta mit Erdbeersauce' }, { name: 'Frischer Obstsalat' } ]
    },
  },
  {
    day: 'Dienstag',
    date: weekDates[1],
    type: 'menu',
    menu: {
      starter: { name: 'Vitello Tonnato mit Kapernäpfeln' },
      soup: { name: 'Tomaten-Consommé mit Basilikum-Nocken' },
      main_meat: { name: 'Saltimbocca alla Romana mit Salbei-Gnocchi' },
      main_fish: { name: 'Seeteufel-Medaillons im Speckmantel auf Safranrisotto' },
      main_veg: { name: 'Auberginen-Parmigiana mit Büffelmozzarella' },
      dessert: { name: 'Klassisches Tiramisu' },
    },
    buffet: { 
        soup: { name: 'Minestrone' },
        starters: [ { name: 'Insalata Caprese' }, { name: 'Bruschetta-Variation' }, { name: 'Meeresfrüchtesalat' }, { name: 'Gegrilltes Gemüse' } ],
        mains: [ { name: 'Osso Buco alla Milanese' }, { name: 'Piccata Lombarda' }, { name: 'Lasagne al Forno' }, { name: 'Dorade vom Grill mit Kräutern' } ],
        vegetarian: [ { name: 'Risotto ai Funghi' }, { name: 'Cannelloni mit Ricotta und Spinat' } ],
        sides: [ { name: 'Polenta' }, { name: 'Gnocchi in Salbeibutter' }, { name: 'Mediterranes Ofengemüse' }, { name: 'Ciabatta und Grissini' } ],
        desserts: [ { name: 'Zabaione' }, { name: 'Torta della Nonna' }, { name: 'Amaretti-Parfait' } ]
    },
  },
  {
    day: 'Mittwoch',
    date: weekDates[2],
    type: 'menu',
    menu: {
      starter: { name: 'Gebeizter Lachs mit Senf-Dill-Sauce' },
      soup: { name: 'Kürbiscremesuppe mit Kernöl und gerösteten Kernen' },
      main_meat: { name: 'Wiener Schnitzel vom Kalb mit Petersilkartoffeln' },
      main_fish: { name: 'Gebratene Forelle "Müllerin Art" mit Mandelbutter' },
      main_veg: { name: 'Käsespätzle mit Röstzwiebeln und Berkäse' },
      dessert: { name: 'Apfelstrudel mit Vanillesauce' },
    },
    buffet: { 
        soup: { name: 'Frittatensuppe' },
        starters: [ { name: 'Brettljause mit verschiedenen Wurst- und Käsesorten' }, { name: 'Backhendlsalat' }, { name: 'Tafelspitz-Sülze' }, { name: 'Käferbohnensalat' } ],
        mains: [ { name: 'Tafelspitz mit Krensauce' }, { name: 'Gefüllte Kalbsbrust' }, { name: 'Kärntner Kasnudeln' }, { name: 'Zwiebelrostbraten' } ],
        vegetarian: [ { name: 'Eierschwammerlgulasch mit Semmelknödel' }, { name: 'Spinatknödel mit brauner Butter' } ],
        sides: [ { name: 'Serviettenknödel' }, { name: 'Apfelrotkohl' }, { name: 'Erdäpfelschmarrn' }, { name: 'Speckkrautsalat' } ],
        desserts: [ { name: 'Kaiserschmarrn' }, { name: 'Marillenknödel' }, { name: 'Sachertorte' } ]
    },
  },
  {
    day: 'Donnerstag',
    date: weekDates[3],
    type: 'menu',
    menu: {
      starter: { name: 'Caesar Salad mit Croûtons und Wachtelei' },
      soup: { name: 'Französische Zwiebelsuppe mit Käse-Croûton' },
      main_meat: { name: 'Rinderroulade "Hausfrauenart" mit Apfelrotkohl' },
      main_fish: { name: 'Gebratener Skrei auf Rahmwirsing' },
      main_veg: { name: 'Semmelknödel mit Waldpilzrahm' },
      dessert: { name: 'Schwarzwälder Kirsch im Glas' },
    },
    buffet: { 
        soup: { name: 'Kartoffelsuppe mit Majoran' },
        starters: [ { name: 'Wurstsalat' }, { name: 'Obatzda mit Brezn' }, { name: 'Sülze mit Remouladensauce' }, { name: 'Matjessalat "Hausfrauenart"' } ],
        mains: [ { name: 'Schweinshaxe mit Dunkelbiersauce' }, { name: 'Leberkäse mit Spiegelei' }, { name: 'Maultaschen in der Brühe' }, { name: 'Sauerbraten' } ],
        vegetarian: [ { name: 'Krautwickel mit vegetarischer Füllung' }, { name: 'Kartoffelpuffer mit Apfelmus' } ],
        sides: [ { name: 'Kartoffelknödel' }, { name: 'Sauerkraut' }, { name: 'Bratkartoffeln' }, { name: 'Gurkensalat mit Dill' } ],
        desserts: [ { name: 'Bayrisch Creme mit Fruchtspiegel' }, { name: 'Rote Grütze mit Vanillesauce' }, { name: 'Dampfnudeln mit Vanillesauce' } ]
    },
  },
  {
    day: 'Freitag',
    date: weekDates[4],
    type: 'menu',
    menu: {
      starter: { name: 'Gegrillte Jakobsmuscheln auf Erbsenpüree' },
      soup: { name: 'Bouillabaisse mit Rouille und Croûtons' },
      main_meat: { name: 'Entenbrust an Orangensauce mit Kartoffelgratin' },
      main_fish: { name: 'Seezunge "Finkenwerder Art" mit Salzkartoffeln' },
      main_veg: { name: 'Gemüse-Curry mit Kokosmilch und Basmatireis' },
      dessert: { name: 'Crème brûlée von der Tonkabohne' },
    },
    buffet: { 
        soup: { name: 'Hummerbisque' },
        starters: [ { name: 'Austern auf Eis' }, { name: 'Räucherfischplatte' }, { name: 'Garnelen-Cocktail' }, { name: 'Thunfischtatar' } ],
        mains: [ { name: 'Paella mit Meeresfrüchten' }, { name: 'Gedämpfter Kabeljau auf Dill-Senf-Sauce' }, { name: 'Moules Frites' }, { name: 'Fisch & Chips' } ],
        vegetarian: [ { name: 'Algen-Pasta mit Kirschtomaten' }, { name: 'Quiche mit Lauch und Ziegenkäse' } ],
        sides: [ { name: 'Baguette mit Aioli' }, { name: 'Dillkartoffeln' }, { name: 'Spinatsalat mit Pinienkernen' }, { name: 'Safranrisotto' } ],
        desserts: [ { name: 'Zitronentarte' }, { name: 'Mousse au Citron' }, { name: 'Sorbet-Variation' } ]
    },
  },
  {
    day: 'Samstag',
    date: weekDates[5],
    type: 'menu',
    menu: {
      starter: { name: 'Tatar vom Weiderind mit Eigelbcreme' },
      soup: { name: 'Steinpilz-Cappuccino mit Trüffelschaum' },
      main_meat: { name: 'Rib-Eye-Steak vom Grill mit Rosmarinkartoffeln' },
      main_fish: { name: 'Ganze Dorade aus dem Ofen mit mediterranem Gemüse' },
      main_veg: { name: 'Gefüllte Paprika mit Couscous und Feta' },
      dessert: { name: 'New York Cheesecake mit Beerenragout' },
    },
    buffet: { 
        soup: { name: 'Gulaschsuppe' },
        starters: [ { name: 'BBQ Chicken Wings' }, { name: 'Coleslaw' }, { name: 'Gegrillte Maiskolben' }, { name: 'Nachos mit Guacamole und Salsa' } ],
        mains: [ { name: 'Pulled Pork Burger' }, { name: 'Spareribs mit BBQ-Sauce' }, { name: 'Gegrillte Rindersteaks' }, { name: 'Chili con Carne' } ],
        vegetarian: [ { name: 'Halloumi-Burger' }, { name: 'Gefüllte Süßkartoffeln' } ],
        sides: [ { name: 'Mac & Cheese' }, { name: 'Baked Beans' }, { name: 'Wedges' }, { name: 'Grüner Salat' } ],
        desserts: [ { name: 'Brownies' }, { name: 'Apple Crumble' }, { name: 'Pancakes mit Ahornsirup' } ]
    },
  },
  {
    day: 'Sonntag',
    date: weekDates[6],
    type: 'menu',
    menu: {
      starter: { name: 'Feldsalat mit Ziegenkäse, Walnüssen und Honig' },
      soup: { name: 'Festtagssuppe mit Grießnockerl und Leberknödel' },
      main_meat: { name: 'Sonntagsbraten vom Kalb mit Rahmsauce und Spätzle' },
      main_fish: { name: 'Lachsfilet im Blätterteig mit Spinat' },
      main_veg: { name: 'Kartoffel-Lauch-Auflauf mit Bergkäse' },
      dessert: { name: 'Kaiserschmarrn mit Apfelmus und Zwetschgenröster' },
    },
    buffet: { 
        soup: { name: 'Hühnerbrühe mit Einlage' },
        starters: [ { name: 'Gefüllte Eier' }, { name: 'Rindfleischsalat' }, { name: 'Gemischter Salat der Saison' }, { name: 'Spargelröllchen im Schinkenmantel' } ],
        mains: [ { name: 'Tafelspitz mit Meerrettichsauce' }, { name: 'Gänsekeule mit Rotkohl und Klößen' }, { name: 'Kalbsrollbraten' }, { name: 'Pochierter Lachs' } ],
        vegetarian: [ { name: 'Serviettenknödel mit Pilzrahm' }, { name: 'Gemüsestrudel mit Kräutersauce' } ],
        sides: [ { name: 'Salzkartoffeln' }, { name: 'Kartoffelgratin' }, { name: 'Prinzessbohnen' }, { name: 'Blumenkohl mit Sauce Hollandaise' } ],
        desserts: [ { name: 'Herrencreme' }, { name: 'Schwarzwälder Kirschtorte' }, { name: 'Obstkuchen vom Blech' } ]
    },
  },
];

const extractDishes = (): SavedDishes => {
  const saved: SavedDishes = {
    starter: [], soup: [], main_meat: [], main_fish: [], main_veg: [], dessert: [],
    buffet_soup: [], buffet_starters: [], buffet_mains: [], buffet_vegetarian: [], buffet_sides: [], buffet_desserts: []
  };

  const addDish = (category: keyof SavedDishes, dish: Dish) => {
    if (dish && dish.name && !saved[category].some(d => d.name === dish.name)) {
      saved[category].push({ name: dish.name });
    }
  };

  INITIAL_WEEK_MENU.forEach(dayMenu => {
    // Menu dishes
    (Object.keys(dayMenu.menu) as (keyof Menu)[]).forEach(course => {
      addDish(course, dayMenu.menu[course]);
    });
    
    // Buffet dishes
    addDish('buffet_soup', dayMenu.buffet.soup);
    dayMenu.buffet.starters.forEach(dish => addDish('buffet_starters', dish));
    dayMenu.buffet.mains.forEach(dish => addDish('buffet_mains', dish));
    dayMenu.buffet.vegetarian.forEach(dish => addDish('buffet_vegetarian', dish));
    dayMenu.buffet.sides.forEach(dish => addDish('buffet_sides', dish));
    dayMenu.buffet.desserts.forEach(dish => addDish('buffet_desserts', dish));
  });

  // Sort all categories alphabetically
  for (const key in saved) {
      saved[key as keyof SavedDishes].sort((a, b) => a.name.localeCompare(b.name));
  }

  return saved;
};

export const INITIAL_SAVED_ISHES: SavedDishes = extractDishes();